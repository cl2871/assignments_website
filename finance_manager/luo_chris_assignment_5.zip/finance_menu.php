<?php 
	session_start();
	error_reporting(E_ALL);
	ini_set("display_errors", 1);
	$cxn = new mysqli("warehouse", "cl2871", "f23jb4zx", "cl2871_luo_db_design");


	$user = "INSERT INTO users (user_id, financial_position, secure_position) VALUES('". session_id() ."', 0, 1);";
	$result = $cxn->query($user);
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<title>Finance Menu</title>
		<link rel="stylesheet" media="only screen and (max-width: 800px)" href="css/mobile.css" />
		<link rel="stylesheet" media="only screen and (min-width: 801px) and (max-width: 1205px)" href="css/tablet.css" />
		<link rel="stylesheet" media="only screen and (min-width: 1206px)" href="css/desktop.css" />
		<meta name="viewport" content="initial-scale=1" />
		<style>

		</style>
	</head>
	<body>
		<div class="container">
			<section>
				<header>
					<h1>Personal Finance Manager</h1>
				</header>
			</section>
			<section>
				<p>
					qweqweqe
				</p>
			</section>
			<section>
			</section>
		</div>
	</body>
</html>